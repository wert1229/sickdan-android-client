package com.kdpark.sickdan.view.control.meallist;

import com.kdpark.sickdan.model.dto.MealCategory;

import lombok.Builder;
import lombok.Data;

@Data
public class MealItem {
    private Long id;
    private String description;
    private MealCategory category;
    private MealCellType type;

    @Builder
    public MealItem(Long id, String description, MealCategory category, MealCellType type) {
        this.id = id;
        this.description = description;
        this.category = category;
        this.type = type;
    }
}

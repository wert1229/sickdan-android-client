package com.kdpark.sickdan.view;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.kdpark.sickdan.R;
import com.kdpark.sickdan.databinding.ActivityMainBinding;
import com.kdpark.sickdan.util.CalendarUtil;
import com.kdpark.sickdan.viewmodel.MainViewModel;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private MainViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        viewModel = new ViewModelProvider(this,
                ViewModelProvider.AndroidViewModelFactory.getInstance(getApplication()))
                .get(MainViewModel.class);

        initData();
        initView();
        initObserver();

        Fragment fragment = new CalendarFragment();

        Bundle bundle = new Bundle();
        bundle.putInt(CalendarUtil.VIEW_MODE_KEY, CalendarUtil.MODE_PRIVATE);
        fragment.setArguments(bundle);

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.act_main_fl_main, fragment).commitAllowingStateLoss();
    }

    private void initData() {}

    private void initView() {
        binding.actMainNavBottom.setOnNavigationItemSelectedListener(menuItem -> {
            Fragment fragment = null;

            switch (menuItem.getItemId()) {
                case R.id.menu_bottom_calendar:
                    fragment = new CalendarFragment();
                    break;
                case R.id.menu_bottom_friend:
                    fragment = new FriendFragment();
                    break;
                case R.id.menu_bottom_statistics:
                    fragment = new FriendFragment();
                    break;
                default:
                    fragment = new FriendFragment();
            }

            Bundle bundle = new Bundle();
            bundle.putInt(CalendarUtil.VIEW_MODE_KEY, CalendarUtil.MODE_PRIVATE);
            fragment.setArguments(bundle);

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.act_main_fl_main, fragment).commitAllowingStateLoss();

            return true;
        });

        setSupportActionBar(binding.actMainTbTop);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("test");
    }

    private void initObserver() {}

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        return super.onOptionsItemSelected(item);
    }
}
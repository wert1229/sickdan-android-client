package com.kdpark.sickdan.model.service;

import com.kdpark.sickdan.model.dto.DailyDto;
import com.kdpark.sickdan.model.dto.MealAddRequest;
import com.kdpark.sickdan.model.dto.MemberDto;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface DailyService {
    @GET("api/v1/members/me/dailies")
    Call<List<DailyDto>> getDailyListData(@Query("yyyymm") String yyyymm);

    @GET("api/v1/members/me/dailies/{yyyymmdd}")
    Call<DailyDto> getDayDetailData(@Path("yyyymmdd") String yyyymmdd);

    @GET("api/v1/members/{memberId}}/dailies")
    Call<List<DailyDto>> getDailyListData(@Path("memberId")Long memberId, @Query("yyyymm") String yyyymm);

    @GET("api/v1/members/{memberId}}/dailies/{yyyymmdd}")
    Call<DailyDto> getDayDetailData(@Path("memberId")Long memberId, @Path("yyyymmdd") String yyyymmdd);

    @POST("api/v1/meals")
    Call<Void> addMeal(@Body MealAddRequest request);

    @GET("api/v1/meals/{mealId}/photos/")
    Call<Void> addMealPhoto(@Path(("mealId")) Long mealId);
}

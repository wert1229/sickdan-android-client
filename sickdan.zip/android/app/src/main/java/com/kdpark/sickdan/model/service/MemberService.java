package com.kdpark.sickdan.model.service;

import com.kdpark.sickdan.model.dto.FriendSearchDto;
import com.kdpark.sickdan.model.dto.MemberDto;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface MemberService {
    @GET("api/v1/members/me")
    Call<MemberDto> getAuthMember();

    @POST("api/v1/members/relationships")
    Call<Void> requestFriend(@Body Long relatedId);

    @GET("api/v1/members")
    Call<FriendSearchDto> searchMemberByEmail(@Query("email") String email);
}

package com.kdpark.sickdan.view;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.ViewModelProvider;

import com.kdpark.sickdan.R;
import com.kdpark.sickdan.databinding.ActivitySignupBinding;
import com.kdpark.sickdan.util.OAuthUtil;
import com.kdpark.sickdan.viewmodel.SignViewModel;
import com.nhn.android.naverlogin.OAuthLogin;

public class SignupActivity extends AppCompatActivity {

    private ActivitySignupBinding binding;
    private SignViewModel viewModel;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_signup);
        viewModel = new ViewModelProvider(this,
                ViewModelProvider.AndroidViewModelFactory.getInstance(getApplication()))
                .get(SignViewModel.class);

        initData();
        initView();
        initObserver();
    }

    private void initData() {
    }

    private void initView() {
        binding.actSignupBtnSignup.setOnClickListener(v -> viewModel.signup(
                binding.actSignupEdEmail.getText().toString(),
                binding.actSignupEdPassword.getText().toString(),
                binding.actSignupEdDisplayname.getText().toString()
        ));
    }

    private void initObserver() {}
}
package com.kdpark.sickdan.view;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.kdpark.sickdan.R;
import com.kdpark.sickdan.databinding.ActivityDailyDetailBinding;
import com.kdpark.sickdan.util.CalendarUtil;
import com.kdpark.sickdan.viewmodel.DailyDetailViewModel;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class DailyDetailActivity extends AppCompatActivity {

    private ActivityDailyDetailBinding binding;
    private DailyDetailViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_daily_detail);
        viewModel = new ViewModelProvider(this,
                ViewModelProvider.AndroidViewModelFactory.getInstance(getApplication()))
                .get(DailyDetailViewModel.class);

        initData();
        initView();
        initObserver();

        //Init Complete
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.act_detail_fl_dayinfo, new DayInfoFragment()).commitAllowingStateLoss();
    }

    private void initData() {
        viewModel.setMode(getIntent().getIntExtra(CalendarUtil.VIEW_MODE_KEY, 0));
        viewModel.setMemberId(getIntent().getLongExtra("memberId", 0));

        String date = getIntent().getStringExtra("date");
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, Integer.parseInt(date.substring(0, 4)));
        calendar.set(Calendar.MONTH, Integer.parseInt(date.substring(4, 6)) - 1);
        calendar.set(Calendar.DATE, Integer.parseInt(date.substring(6)));

        viewModel.setDate(calendar);
    }

    private void initView() {}

    private void initObserver() {
        viewModel.getCurrentDate().observe(this, calendar1 -> {
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM월 dd일");
            binding.actDetailTvDate.setText(dateFormat.format(calendar1.getTime()));
        });

        viewModel.getToastEvent().observe(this, message ->
                Toast.makeText(getApplicationContext(), message.getValue(), Toast.LENGTH_SHORT).show());
    }


}
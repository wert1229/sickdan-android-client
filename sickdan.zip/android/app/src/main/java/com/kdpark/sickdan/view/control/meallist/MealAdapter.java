package com.kdpark.sickdan.view.control.meallist;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.kdpark.sickdan.R;
import com.kdpark.sickdan.model.dto.MealCategory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Getter;

@Getter
public class MealAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>
        implements MealItemMoveCallback.ItemTouchHelperAdapter {

    private Context context;
    private List<MealItem> list;
    private Map<MealCategory, Integer> categoryCountMap;

    private boolean isOrderEditMode = false;

    private onDragStartListener onDragStartListener;
    private onManipulateMealListener onManipulateMealListener;

    public interface onDragStartListener {
        void onDragStart(MealItemViewHolder viewHolder);
    }

    public interface onManipulateMealListener {
        void onAddConfirmed(MealItem item);
        void onEditConfirmed(MealItem item);
        void onDeleteConfirmed(MealItem item);
    }

    public MealAdapter(Context context) {
        this(context, new ArrayList<>());
    }

    public MealAdapter(Context context, List<MealItem> list) {
        super();
        this.context = context;
        categoryCountMap = new HashMap<>();
        this.list = getListWithSection(list);
    }

    public void setList(List<MealItem> list) {
        this.list = getListWithSection(list);
    }

    public void setOnDragStartListener(MealAdapter.onDragStartListener onDragStartListener) {
        this.onDragStartListener = onDragStartListener;
    }

    public void setOnManipulateMealListener(onManipulateMealListener onManipulateMealListener) {
        this.onManipulateMealListener = onManipulateMealListener;
    }


    public void setOrderEditMode(boolean mode) {
        this.isOrderEditMode = mode;
        removeNotConfirmedItem();
        notifyDataSetChanged();
    }

    private List<MealItem> getListWithSection(List<MealItem> list) {
        for (MealCategory category : MealCategory.values()) {
            if (category == MealCategory.NONE) continue;
            list.add(new MealItem(0L, "", category, MealCellType.SECTION));
            categoryCountMap.put(category, 0);
        }

        for (int i = 0; i < list.size(); i++) {
            MealCategory category = list.get(i).getCategory();
            if (list.get(i).getType() == MealCellType.SECTION) continue;
            categoryCountMap.computeIfPresent(category, (key, value) -> value + 1);
        }

        Collections.sort(list, (m1, m2) -> m1.getCategory().compareTo(m2.getCategory()) != 0
                   ? m1.getCategory().compareTo(m2.getCategory())
                   : m1.getType().compareTo(m2.getType())
        );

        return list;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        RecyclerView.ViewHolder holder;

        if (viewType == MealCellType.SECTION.getInt()) {
            view = LayoutInflater.from(context).inflate(R.layout.meal_list_section, parent, false);
            holder = new MealSectionViewHolder(view);
        } else if (viewType == MealCellType.EDIT.getInt() || viewType == MealCellType.NEW.getInt()) {
            view = LayoutInflater.from(context).inflate(R.layout.meal_list_edit, parent, false);
            holder = new MealEditViewHolder(view);
        } else {
            view = LayoutInflater.from(context).inflate(R.layout.meal_list_item, parent, false);
            holder = new MealItemViewHolder(view);
        }

        return holder;
    }

    @Override
    public int getItemViewType(int position) {
        return list.get(position).getType().getInt();
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int pos) {
        int viewType = getItemViewType(pos);

        if (viewType == MealCellType.SECTION.getInt()) {
            MealSectionViewHolder viewHolder = (MealSectionViewHolder) holder;
            viewHolder.title.setText(list.get(pos).getCategory().toString());
            viewHolder.add.setVisibility(isOrderEditMode ? View.INVISIBLE : View.VISIBLE);
            viewHolder.add.setOnClickListener(v -> {
                removeNotConfirmedItem();
                
                MealItem item = list.get(pos);
                MealItem newItem = MealItem.builder()
                        .category(item.getCategory())
                        .description("")
                        .type(MealCellType.NEW)
                        .build();
                
                int index = pos + categoryCountMap.get(item.getCategory()) + 1;
                list.add(index, newItem);
                notifyDataSetChanged();
            });
        } else if (viewType == MealCellType.EDIT.getInt()) {
            MealEditViewHolder viewHolder = (MealEditViewHolder) holder;

            viewHolder.description.setText(list.get(pos).getDescription());

            viewHolder.confirm.setOnClickListener(v -> {
                String after =  viewHolder.description.getText().toString();
                if (!after.isEmpty()) list.get(pos).setDescription(after);
                
                list.get(pos).setType(MealCellType.ITEM);

                onManipulateMealListener.onEditConfirmed(list.get(pos));
                notifyDataSetChanged();
            });

        } else if (viewType == MealCellType.NEW.getInt()) {
            MealEditViewHolder viewHolder = (MealEditViewHolder) holder;

            viewHolder.description.setText(list.get(pos).getDescription());

            viewHolder.confirm.setOnClickListener(v -> {
                String after =  viewHolder.description.getText().toString();

                if (after.isEmpty()) {
                    removeNotConfirmedItem();
                    return;
                }

                list.get(pos).setDescription(after);
                list.get(pos).setType(MealCellType.ITEM);

                categoryCountMap.computeIfPresent(list.get(pos).getCategory(), (key, value) -> value + 1);
                onManipulateMealListener.onAddConfirmed(list.get(pos));
                notifyDataSetChanged();
            });

        } else {
            MealItemViewHolder viewHolder = (MealItemViewHolder) holder;
            viewHolder.description.setText(list.get(pos).getDescription());

            viewHolder.handler.setVisibility(isOrderEditMode ? View.VISIBLE : View.INVISIBLE);
            viewHolder.handler.setOnTouchListener((v, event) -> {
                if (event.getAction() == MotionEvent.ACTION_DOWN)
                    onDragStartListener.onDragStart(viewHolder);
                return false;
            });

            viewHolder.itemView.setOnLongClickListener(v -> {
                removeNotConfirmedItem();
                list.get(pos).setType(MealCellType.EDIT);
                notifyItemChanged(pos);
                return false;
            });
        }

    }
    @Override
    public int getItemCount() {
        return list.size();
    }

    @Override
    public void onItemMove(int fromPos, int targetPos) {
        if (targetPos == 0) return;

        MealItem fromItem = list.remove(fromPos);
        categoryCountMap.computeIfPresent(fromItem.getCategory(), (key, value) -> value - 1);

        fromItem.setCategory(list.get(targetPos - 1).getCategory());
        categoryCountMap.computeIfPresent(fromItem.getCategory(), (key, value) -> value + 1);

        list.add(targetPos, fromItem);
        notifyItemMoved(fromPos, targetPos);
    }

    @Override
    public void onItemDismiss(int pos) {

    }

    public MealItem removeNotConfirmedItem() {
        MealItem currentEditItem = null;

        for (MealItem mealItem : list) {
            if (mealItem.getType() == MealCellType.NEW) {
                currentEditItem = mealItem;
            } else if (mealItem.getType() == MealCellType.EDIT) {
                mealItem.setType(MealCellType.ITEM);
            }
        }

        if (currentEditItem != null) list.remove(currentEditItem);

        notifyDataSetChanged();
        return currentEditItem;
    }


    public static class MealItemViewHolder extends RecyclerView.ViewHolder {
        TextView description;
        ImageButton handler;

        public MealItemViewHolder(@NonNull View itemView) {
            super(itemView);
            this.description = itemView.findViewById(R.id.lay_mealitem_tv_description);
            this.handler = itemView.findViewById(R.id.lay_mealitem_ib_handler);
        }
    }

    public static class MealEditViewHolder extends RecyclerView.ViewHolder {
        EditText description;
        ImageButton confirm;

        public MealEditViewHolder(@NonNull View itemView) {
            super(itemView);
            this.description = itemView.findViewById(R.id.lay_mealitem_ed_description);
            this.confirm = itemView.findViewById(R.id.lay_mealitem_ib_confirm);
        }
    }

    public static class MealSectionViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        ImageButton add;

        public MealSectionViewHolder(@NonNull View itemView) {
            super(itemView);
            this.title = itemView.findViewById(R.id.lay_mealsection_tv_title);
            this.add = itemView.findViewById(R.id.lay_mealsection_ib_add);
        }
    }
}
package com.kdpark.sickdan.util;

public class OAuthUtil {
    public static final String CLIENT_NAME = "sickdan";

    public static final String NAVER_CLIENT_ID = "LXd3qV5EDZaV1EAaKSvw";
    public static final String NAVER_CLIENT_SECRET = "7GiFokyXH3";
}
